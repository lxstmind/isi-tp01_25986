The pdi-dataservice-client zip contains all of the jar files required to make a JDBC connection to a running Data Service.

Configuration documentation can be found at https://docs.hitachivantara.com/r/en-us/pentaho-data-integration-and-analytics/10.2.x/mk-95pdia003/advanced-pentaho-data-integration-topics/pentaho-data-services
